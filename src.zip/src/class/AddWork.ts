export class Addwork{
     ProjectWorkDate:any  
      ProjectId:string=''  
      ModuleId:string=''  
      ContactName:string=''  
      ContactNo:string=''  
      CalledDescription:string=''  
 ProjectWorkStatusId:number=1


 Project_WorkId:string=''
 ProjectName:string=''
 ModuleName:string=''

 ATTACH_FILE_COUNT:number=0
}