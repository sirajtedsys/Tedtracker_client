import { EmpExpenceDetails } from "./EmpExpenceDetails"

export class EmpExpence{
    accMasterId:string=''
    TotalAmt:string=''
    ExpDate:string=''
    ProjectId:string=''
    EmpExpenceDetails:EmpExpenceDetails[]=[]
}