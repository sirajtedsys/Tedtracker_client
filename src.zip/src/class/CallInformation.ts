export class CallInformation{
    P_WORK_ID:string| null= null;
    P_CALL_ID:string| null= null;
    P_EMP_ID:string| null= null;
    P_CREATE_USER:string| null= null;
    P_CALL_NOTE:string| null= null;

}